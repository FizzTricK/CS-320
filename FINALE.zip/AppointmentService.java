import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private Map<String, Appointment> appointments;
    public AppointmentService() {
        this.appointments = new HashMap<>();
    }
    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointment.getAppointmentID() == null) {
            throw new IllegalArgumentException("Appointment and the Appointment ID cannot be empty.");
        }
        if (appointments.containsKey(appointment.getAppointmentID())) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }
        appointments.put(appointment.getAppointmentID(), appointment);
    }
    public void deleteAppointment(String appointmentID) {
        if (appointmentID == null) {
            throw new IllegalArgumentException("Appointment ID cannot be empty.");
        }
        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("There is no appointment found with the given ID.");
        }
        appointments.remove(appointmentID);
    } }

