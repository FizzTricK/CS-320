import org.junit.jupiter.api.Test;
//Ian Gottwik
public class TaskTest {


    public void testTaskIDLength() {
        Task task = new Task("7897897890", "Name", "Description");
        assertEquals("7897897890", task.getTaskID());
    public void testNullNameField() {
        new Task("7897897890", null, "Description");

    }
}