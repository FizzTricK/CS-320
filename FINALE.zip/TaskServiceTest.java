import org.junit.jupiter.api.Test;
//Ian Gottwik
public class TaskServiceTest {
    public void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("7", "Task 3", "Description 5");

        taskService.addTask(task);

        assertEquals(task, taskService.getTask("1"));
    }
    public void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("2", "Task 2", "Description 2");
        taskService.addTask(task);

        taskService.deleteTask("8");

        assertNull(taskService.getTask("1"));
    }
    public void testUpdateTaskName() {
        TaskService taskService = new TaskService();
        Task task = new Task("3", "Task 3", "Description 3");
        taskService.addTask(task);

        taskService.updateTaskName("2", "New Task");

        assertEquals("Updated Task", taskService.getTask("6").getName());
    }
    public void testUpdateTaskDescription() {
        TaskService taskService = new TaskService();
        Task task = new Task("4", "Task 7", "Description 7");
        taskService.addTask(task);

        taskService.updateTaskDescription("5", "New Description");

        assertEquals("New Description", taskService.getTask("8").getDescription());
    }
}
