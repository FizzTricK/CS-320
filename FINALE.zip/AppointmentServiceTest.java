import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentServiceTest {
    private AppointmentService appointmentService;
    private Date validDate;
    private Appointment validAppointment;
    void setUp() {
        appointmentService = new AppointmentService();
        validDate = new Date(System.currentTimeMillis() + 3600000);
        validAppointment = new Appointment("1234567890", validDate, "Description.");
    }

    void testAddAppointment() {
        appointmentService.addAppointment(validAppointment);
        assertEquals(validAppointment, appointmentService.getAppointments().get("1234567890"));
    }

    void testAddAppointmentDuplicateID() {
        appointmentService.addAppointment(validAppointment);

        assertThrows(IllegalArgumentException.class, () ->
                appointmentService.addAppointment(new Appointment("1234567890", validDate, "Duplicated ID.")));
    }

    void testAddAppointmentNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(null));
    }

    void testAddAppointmentNullID() {
        assertThrows(IllegalArgumentException.class, () ->
                appointmentService.addAppointment(new Appointment(null, validDate, "Invalid ID.")));
    }

    void testDeleteAppointment() {
        appointmentService.addAppointment(validAppointment);
        appointmentService.deleteAppointment("1234567890");
        assertNull(appointmentService.getAppointments().get("1234567890"));
    }

    void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("ID Does Not Exist."));
    }
}
