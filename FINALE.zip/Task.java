// Ian Gottwik
public class Task {
    private final String taskID;
    private final String name;
    private final String description;

    public Task(String taskID, String name, String description) {
        if (taskID == null || taskID.length() > 10) {
            throw new IllegalArgumentException("Task ID must be within 10 characters.");
        }
        if (name == null) {
            throw new IllegalArgumentException("Name cannot be null.");     
        }
        if (name.length() > 20) {
            throw new IllegalArgumentException("Name must be within 20 characters.");
        }
        if (description == null) {
            throw new IllegalArgumentException("Description cannot be null"); }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description must be within 50 characters.");
        }
        this.taskID = taskID;
        this.name = name;
        this.description = description;
    }

    public String getTaskID() {
        return taskID;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

	public void setDescription(String description2) {
		
		
	}

	public void setName(String name2) {
	
		
	}

	public String getTaskId() {
	
		return null;
	}
}

