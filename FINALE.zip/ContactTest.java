import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
// Ian Gottwik
public class ContactTest {
    public void testContactIDLessThan10() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jake", "Bob", "7897897980", "123 Port Dr."));
    }
    public void testContactIDEquals10() {
        assertDoesNotThrow(() -> new Contact("1234567890", "Elliot", "Tenth", "8454566123", "555 Whomst Dr."));
    }
    public void testContactIDGreaterThan10() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Pam", "Kakarot", "78979879878", "111 Toon Dr."));
    }
    public void testContactIDIsNull() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Null", "Name", "0000000000", "Null"));
    }
}
