import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//ian gottwik
public class ContactService {
    private Map<String, Contact> Contacts;

    public ContactService() {
        Contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {
        Contacts.put(contact.getId(), contact);
    }

    public void deleteContact(String contactId) {
        Contacts.remove(contactId);
    }

    public void UpdateContactField(String contactId, String fieldName, String newValue) {
        Contact contact = Contacts.get(contactId);
        if (contact != null) {
            switch (fieldName.toLowerCase()) {
                case "Firstname":
                    contact = new Contact(contact.getId(), newValue, contact.getLastName(), contact.getPhone(), contact.getAddress());
                    break;
                case "Lastname":
                    contact = new Contact(contact.getId(), contact.getFirstName(), newValue, contact.getPhone(), contact.getAddress());
                    break;
                case "Phone":
                    contact = new Contact(contact.getId(), contact.getFirstName(), contact.getLastName(), newValue, contact.getAddress());
                    break;
                case "Address":
                    contact = new Contact(contact.getId(), contact.getFirstName(), contact.getLastName(), contact.getPhone(), newValue);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid name given.");
            }
            Contacts.put(contactId, contact);
        }
    }

    public Contact getContact(String contactId) {
        return Contacts.get(contactId);
    }

    public List<Contact> getAllContacts() {
        return new ArrayList<>(Contacts.values());
    }
}
