import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
//Ian Gottwik
public class ContactServiceTest {
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "Jake", "Bob", "7897897980", "123 Port Dr.");
        contactService.addContact(contact);
        assertNotNull(contactService.getContact("1234567890"));
    }
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "Jake", "Bob", "7897897890", "123 Port Dr.");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        assertNull(contactService.getContact("1234567890"));
    }
    public void testUpdateContactField() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "Jake", "Bob", "7897897890", "123 Port Dr.");
        contactService.addContact(contact);

        contactService.update